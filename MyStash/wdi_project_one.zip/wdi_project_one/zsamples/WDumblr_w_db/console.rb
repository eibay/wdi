require_relative './lib/connection'
require_relative './lib/author'
require_relative './lib/post'
require_relative './lib/image'
require 'pry'




binding.pry

