require 'pry'
require_relative './lib/connection'
require_relative './lib/house'
require_relative './lib/character'

binding.pry